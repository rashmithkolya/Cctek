
import React, { useState, useCallback } from 'react';
import { usePrintJobs } from '../hooks/usePrintJobs';
import { ALLOWED_FILE_TYPES, MAX_FILE_SIZE_BYTES } from '../constants';
import { UploadCloud, File as FileIcon, Loader2, CheckCircle, AlertTriangle } from 'lucide-react';

const StudentPortal: React.FC = () => {
  const [studentName, setStudentName] = useState('');
  const [copies, setCopies] = useState(1);
  const [notes, setNotes] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submittedJobId, setSubmittedJobId] = useState<string | null>(null);

  const { addJob, loading } = usePrintJobs();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setError(null);
      if (!ALLOWED_FILE_TYPES.includes(selectedFile.type)) {
        setError(`Invalid file type. Please upload PDF, DOCX, JPG, or PNG.`);
        return;
      }
      if (selectedFile.size > MAX_FILE_SIZE_BYTES) {
        setError(`File is too large. Maximum size is ${MAX_FILE_SIZE_BYTES / 1024 / 1024}MB.`);
        return;
      }
      setFile(selectedFile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !studentName.trim() || copies < 1) {
      setError('Please fill out all required fields and select a file.');
      return;
    }
    setError(null);
    try {
        const { id } = await addJob({
            studentName: studentName.trim(),
            fileName: file.name,
            fileType: file.type,
            fileSize: file.size,
            copies,
            notes,
            file,
        });
        setSubmittedJobId(id);
    } catch (err) {
        setError('An unexpected error occurred during submission. Please try again.');
    }
  };

  const resetForm = () => {
    setStudentName('');
    setCopies(1);
    setNotes('');
    setFile(null);
    setError(null);
    setSubmittedJobId(null);
  };

  if (submittedJobId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-900 p-4">
        <div className="w-full max-w-md text-center bg-white dark:bg-slate-800 rounded-xl shadow-lg p-8 transform transition-all hover:scale-105">
            <CheckCircle className="mx-auto h-16 w-16 text-green-500" />
            <h2 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">Submission Successful!</h2>
            <p className="mt-2 text-slate-600 dark:text-slate-400">Your file has been uploaded.</p>
            <div className="mt-6 bg-slate-100 dark:bg-slate-700 rounded-lg p-4">
                <p className="text-sm font-medium text-slate-500 dark:text-slate-300">Your Job ID is:</p>
                <p className="text-xl font-mono font-bold text-indigo-600 dark:text-indigo-400 break-all">{submittedJobId}</p>
            </div>
            <p className="mt-4 text-xs text-slate-500">Please provide this ID at the CCTek desk if needed.</p>
            <button
            onClick={resetForm}
            className="mt-8 w-full bg-indigo-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-transform transform hover:scale-105"
            >
            Submit Another File
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-900 p-4">
        <div className="w-full max-w-lg mx-auto">
            <div className="text-center mb-8">
                <img src="https://picsum.photos/80/80" alt="GPT Bantwal Logo" className="mx-auto rounded-full mb-4"/>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">GPT Bantwal CCTek</h1>
                <p className="text-slate-600 dark:text-slate-400">Print Job Submission Portal</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6 bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg">
            <div>
                <label htmlFor="studentName" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Full Name</label>
                <input
                type="text"
                id="studentName"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                required
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Enter your name"
                />
            </div>

            <div>
                <label htmlFor="copies" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Number of Copies</label>
                <input
                type="number"
                id="copies"
                value={copies}
                onChange={(e) => setCopies(Math.max(1, parseInt(e.target.value) || 1))}
                min="1"
                required
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
            </div>
            
            <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">File to Print</label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md">
                    <div className="space-y-1 text-center">
                    {file ? (
                        <>
                            <FileIcon className="mx-auto h-12 w-12 text-slate-400" />
                            <p className="text-sm text-slate-600 dark:text-slate-400">{file.name}</p>
                            <p className="text-xs text-slate-500">{Math.round(file.size / 1024)} KB</p>
                        </>
                    ) : (
                        <>
                            <UploadCloud className="mx-auto h-12 w-12 text-slate-400" />
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                <span className="font-semibold text-indigo-600 dark:text-indigo-400 cursor-pointer hover:underline">Upload a file</span> or drag and drop
                            </p>
                            <p className="text-xs text-slate-500">PDF, DOCX, JPG, PNG up to 10MB</p>
                        </>
                    )}
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} />
                    </div>
                </div>
            </div>

            <div>
                <label htmlFor="notes" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Notes / Instructions</label>
                <textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="e.g., Print pages 2-5 only, black & white"
                />
            </div>
            
            {error && (
                <div className="flex items-center p-3 text-sm text-red-700 bg-red-100 dark:bg-red-900 dark:text-red-200 rounded-lg">
                    <AlertTriangle className="w-5 h-5 mr-2 flex-shrink-0"/>
                    <span>{error}</span>
                </div>
            )}

            <div>
                <button
                type="submit"
                disabled={loading || !file}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105"
                >
                {loading ? <Loader2 className="animate-spin h-5 w-5" /> : 'Submit for Printing'}
                </button>
            </div>
            </form>
        </div>
    </div>
  );
};

export default StudentPortal;
