
import React, { useState, useEffect, useMemo } from 'react';
import { usePrintJobs } from '../hooks/usePrintJobs';
import { ADMIN_EMAIL, ADMIN_PASSWORD } from '../constants';
import { JobStatus, ActivityAction } from '../types';
import type { PrintJob, ActivityLog } from '../types';
import JobCard from './JobCard';
import FilePreviewModal from './FilePreviewModal';
import { formatDistanceToNow } from 'date-fns';
import { LogIn, List, Activity, User, FileText, Check, Printer, Trash2 } from 'lucide-react';

const AdminLogin: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
            sessionStorage.setItem('isAdminLoggedIn', 'true');
            onLogin();
        } else {
            setError('Invalid credentials. Please try again.');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-slate-900">
            <div className="w-full max-w-sm p-8 space-y-6 bg-white dark:bg-slate-800 rounded-xl shadow-lg">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Admin Login</h1>
                    <p className="text-slate-500 dark:text-slate-400">GPT Bantwal Print Portal</p>
                </div>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
                        <input
                            type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} required
                            className="mt-1 w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
                        <input
                            type="password" id="password" value={password} onChange={e => setPassword(e.target.value)} required
                            className="mt-1 w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        />
                    </div>
                    {error && <p className="text-sm text-red-500">{error}</p>}
                    <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        <LogIn className="mr-2 h-5 w-5"/> Sign In
                    </button>
                </form>
            </div>
        </div>
    );
};

const AdminDashboard: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
    const { jobs, activityLog, updateJobStatus, deleteJob } = usePrintJobs();
    const [selectedJob, setSelectedJob] = useState<PrintJob | null>(null);
    const [filter, setFilter] = useState<JobStatus | 'All'>('All');

    const filteredJobs = useMemo(() => {
        const sorted = [...jobs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        if (filter === 'All') return sorted;
        return sorted.filter(job => job.status === filter);
    }, [jobs, filter]);

    const statusCounts = useMemo(() => {
        return jobs.reduce((acc, job) => {
            acc[job.status] = (acc[job.status] || 0) + 1;
            return acc;
        }, {} as Record<JobStatus, number>);
    }, [jobs]);

    const actionIcons: Record<ActivityAction, React.ReactElement> = {
        [ActivityAction.SUBMITTED]: <FileText className="h-4 w-4 text-blue-500" />,
        [ActivityAction.APPROVED]: <Check className="h-4 w-4 text-yellow-500" />,
        [ActivityAction.PRINTED]: <Printer className="h-4 w-4 text-green-500" />,
        [ActivityAction.DELETED]: <Trash2 className="h-4 w-4 text-red-500" />,
    };

    return (
        <div className="min-h-screen bg-slate-100 dark:bg-slate-900">
            <header className="bg-white dark:bg-slate-800 shadow-md sticky top-0 z-10">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
                    <h1 className="text-xl font-bold">Admin Dashboard</h1>
                    <button onClick={onLogout} className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline">Logout</button>
                </div>
            </header>
            <main className="container mx-auto p-4 sm:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <div className="mb-6">
                        <div className="flex space-x-2 border-b border-slate-200 dark:border-slate-700">
                            {(['All', ...Object.values(JobStatus)] as const).map(status => (
                                <button key={status} onClick={() => setFilter(status)} className={`px-4 py-2 text-sm font-medium transition-colors ${filter === status ? 'border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
                                    {status} <span className="ml-1 text-xs bg-slate-200 dark:bg-slate-700 rounded-full px-2 py-0.5">
                                      {status === 'All' ? jobs.length : (statusCounts[status] || 0)}
                                    </span>
                                </button>
                            ))}
                        </div>
                    </div>
                    {filteredJobs.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {filteredJobs.map(job => (
                                <JobCard key={job.id} job={job} onUpdateStatus={updateJobStatus} onDelete={deleteJob} onPreview={() => setSelectedJob(job)} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-lg">
                            <List className="mx-auto h-12 w-12 text-slate-400"/>
                            <h3 className="mt-2 text-sm font-medium text-slate-900 dark:text-white">No jobs found</h3>
                            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">There are no jobs with the status "{filter}".</p>
                        </div>
                    )}
                </div>
                <aside className="lg:col-span-1">
                    <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 sticky top-24">
                        <h2 className="text-lg font-semibold flex items-center mb-4"><Activity className="mr-2 h-5 w-5"/>Activity Log</h2>
                        <ul className="space-y-4 max-h-[70vh] overflow-y-auto">
                           {activityLog.slice(0, 20).map(log => (
                               <li key={log.id} className="flex items-start space-x-3">
                                   <div className="flex-shrink-0 bg-slate-100 dark:bg-slate-700 rounded-full p-1.5">{actionIcons[log.action]}</div>
                                   <div>
                                       <p className="text-sm text-slate-800 dark:text-slate-200">
                                           <span className="font-semibold">{log.studentName}</span> {log.action.replace('job', `'${log.fileName}'`)}.
                                       </p>
                                       <p className="text-xs text-slate-500 dark:text-slate-400" title={new Date(log.timestamp).toLocaleString()}>
                                           {formatDistanceToNow(new Date(log.timestamp), { addSuffix: true })}
                                       </p>
                                   </div>
                               </li>
                           ))}
                           {activityLog.length === 0 && <p className="text-sm text-slate-500">No recent activity.</p>}
                        </ul>
                    </div>
                </aside>
            </main>
            {selectedJob && <FilePreviewModal job={selectedJob} onClose={() => setSelectedJob(null)} />}
        </div>
    );
};

const AdminPortal: React.FC = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(sessionStorage.getItem('isAdminLoggedIn') === 'true');

    const handleLogin = () => {
        setIsLoggedIn(true);
    };

    const handleLogout = () => {
        sessionStorage.removeItem('isAdminLoggedIn');
        setIsLoggedIn(false);
    };

    return isLoggedIn ? <AdminDashboard onLogout={handleLogout} /> : <AdminLogin onLogin={handleLogin} />;
};

export default AdminPortal;
