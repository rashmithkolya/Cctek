
import React from 'react';
import type { PrintJob } from '../types';
import { JobStatus } from '../types';
import { formatDistanceToNow } from 'date-fns';
import { User, Hash, FileText, Calendar, Edit, Eye, Printer, Check, Trash2 } from 'lucide-react';

interface JobCardProps {
  job: PrintJob;
  onUpdateStatus: (jobId: string, status: JobStatus) => void;
  onDelete: (jobId: string) => void;
  onPreview: (job: PrintJob) => void;
}

const statusStyles: Record<JobStatus, string> = {
  [JobStatus.Uploaded]: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  [JobStatus.Approved]: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  [JobStatus.Printed]: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
};

const JobCard: React.FC<JobCardProps> = ({ job, onUpdateStatus, onDelete, onPreview }) => {
  const fileTypeShort = job.fileName.split('.').pop()?.toUpperCase();

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col">
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100 break-all">{job.studentName}</h3>
          <span className={`px-2.5 py-0.5 text-xs font-semibold rounded-full ${statusStyles[job.status]}`}>{job.status}</span>
        </div>
        
        <div className="space-y-3 text-sm text-slate-600 dark:text-slate-400">
          <div className="flex items-center">
            <FileText className="h-4 w-4 mr-2 text-slate-400" />
            <span className="truncate flex-1" title={job.fileName}>{job.fileName}</span>
            <span className="ml-2 flex-shrink-0 text-xs font-mono bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded">{fileTypeShort}</span>
          </div>
          <div className="flex items-center">
            <Hash className="h-4 w-4 mr-2 text-slate-400" />
            <span>{job.copies} Cop{job.copies > 1 ? 'ies' : 'y'}</span>
          </div>
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2 text-slate-400" />
            <span title={new Date(job.timestamp).toLocaleString()}>{formatDistanceToNow(new Date(job.timestamp), { addSuffix: true })}</span>
          </div>
           {job.notes && (
            <div className="flex items-start">
              <Edit className="h-4 w-4 mr-2 mt-0.5 text-slate-400 flex-shrink-0" />
              <p className="bg-slate-50 dark:bg-slate-700/50 p-2 rounded-md text-xs italic border-l-2 border-slate-300 dark:border-slate-600 w-full">{job.notes}</p>
            </div>
           )}
        </div>
      </div>
      
      <div className="border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 p-3 flex justify-between items-center rounded-b-lg space-x-2">
        <button onClick={() => onPreview(job)} className="flex items-center text-sm text-slate-600 hover:text-indigo-600 dark:text-slate-300 dark:hover:text-indigo-400 font-medium transition-colors p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700">
          <Eye className="h-4 w-4 mr-1.5" /> Preview
        </button>
        <div className="flex space-x-1">
          {job.status === JobStatus.Uploaded && (
            <button onClick={() => onUpdateStatus(job.id, JobStatus.Approved)} className="p-2 rounded-md text-yellow-600 hover:bg-yellow-100 dark:hover:bg-yellow-900/50 transition-colors" title="Approve & Print">
              <Printer className="h-5 w-5" />
            </button>
          )}
          {job.status === JobStatus.Approved && (
            <button onClick={() => onUpdateStatus(job.id, JobStatus.Printed)} className="p-2 rounded-md text-green-600 hover:bg-green-100 dark:hover:bg-green-900/50 transition-colors" title="Mark Printed">
              <Check className="h-5 w-5" />
            </button>
          )}
          <button onClick={() => onDelete(job.id)} className="p-2 rounded-md text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors" title="Delete Job">
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
