
import React from 'react';
import type { PrintJob } from '../types';
import { X, Download, File } from 'lucide-react';

interface FilePreviewModalProps {
  job: PrintJob;
  onClose: () => void;
}

const FilePreviewModal: React.FC<FilePreviewModalProps> = ({ job, onClose }) => {
  const isImage = job.fileType.startsWith('image/');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col transform transition-all" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
          <h3 className="font-semibold text-lg truncate" title={job.fileName}>{job.fileName}</h3>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700">
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="p-4 flex-grow overflow-auto">
          {isImage ? (
            <img src={job.fileDataUrl} alt="File preview" className="max-w-full max-h-[70vh] mx-auto object-contain" />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-slate-50 dark:bg-slate-700/50 rounded-md">
              <File className="h-24 w-24 text-slate-400 mb-4" />
              <h4 className="text-xl font-semibold">Preview not available</h4>
              <p className="text-slate-500 dark:text-slate-400 mt-1">
                You can download the file to view it locally.
              </p>
            </div>
          )}
        </div>

        <div className="flex justify-end p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
            <a
                href={job.fileDataUrl}
                download={job.fileName}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
                <Download className="h-5 w-5 mr-2" />
                Download File
            </a>
        </div>
      </div>
    </div>
  );
};

export default FilePreviewModal;
