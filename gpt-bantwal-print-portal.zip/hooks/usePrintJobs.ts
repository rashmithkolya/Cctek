import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { differenceInDays } from 'date-fns';
import type { PrintJob, ActivityLog } from '../types';
import { JobStatus, ActivityAction } from '../types';
import { RETENTION_DAYS } from '../constants';

interface PrintJobsContextType {
  jobs: PrintJob[];
  activityLog: ActivityLog[];
  addJob: (jobData: Omit<PrintJob, 'id' | 'status' | 'timestamp' | 'fileDataUrl'> & { file: File }) => Promise<{id: string}>;
  updateJobStatus: (jobId: string, status: JobStatus) => void;
  deleteJob: (jobId: string) => void;
  loading: boolean;
  error: string | null;
}

const PrintJobsContext = createContext<PrintJobsContextType | undefined>(undefined);

const fileToDataUrl = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
    reader.readAsDataURL(file);
  });
};

export const PrintJobsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [jobs, setJobs] = useState<PrintJob[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const storedJobs = localStorage.getItem('printJobs');
      const storedLogs = localStorage.getItem('activityLog');
      
      const now = new Date();
      
      let initialJobs: PrintJob[] = storedJobs ? JSON.parse(storedJobs) : [];
      // Apply retention policy
      initialJobs = initialJobs.filter(job => differenceInDays(now, new Date(job.timestamp)) < RETENTION_DAYS);

      let initialLogs: ActivityLog[] = storedLogs ? JSON.parse(storedLogs) : [];
      initialLogs = initialLogs.filter(log => differenceInDays(now, new Date(log.timestamp)) < RETENTION_DAYS);
      
      setJobs(initialJobs);
      setActivityLog(initialLogs);
      localStorage.setItem('printJobs', JSON.stringify(initialJobs));
      localStorage.setItem('activityLog', JSON.stringify(initialLogs));

    } catch (e) {
      console.error("Failed to load data from localStorage", e);
      setError("Failed to load data. Please clear your browser cache.");
    } finally {
      setLoading(false);
    }
  }, []);

  const updateLocalStorage = (newJobs: PrintJob[], newLog: ActivityLog[]) => {
    localStorage.setItem('printJobs', JSON.stringify(newJobs));
    localStorage.setItem('activityLog', JSON.stringify(newLog));
  };
  
  const addActivity = useCallback((job: PrintJob, action: ActivityAction, currentLog: ActivityLog[]) => {
      const newLogEntry: ActivityLog = {
          id: uuidv4(),
          jobId: job.id,
          studentName: job.studentName,
          fileName: job.fileName,
          action,
          timestamp: new Date().toISOString(),
      };
      const updatedLog = [newLogEntry, ...currentLog];
      setActivityLog(updatedLog);
      return updatedLog;
  }, []);

  const addJob = async (jobData: Omit<PrintJob, 'id' | 'status' | 'timestamp' | 'fileDataUrl'> & { file: File }) => {
    setLoading(true);
    try {
      const fileDataUrl = await fileToDataUrl(jobData.file);
      const newJob: PrintJob = {
        ...jobData,
        id: uuidv4(),
        status: JobStatus.Uploaded,
        timestamp: new Date().toISOString(),
        fileDataUrl,
      };
      
      const updatedJobs = [...jobs, newJob];
      setJobs(updatedJobs);
      
      const updatedLog = addActivity(newJob, ActivityAction.SUBMITTED, activityLog);
      updateLocalStorage(updatedJobs, updatedLog);
      return { id: newJob.id };
    } catch (e) {
      console.error("Failed to add job", e);
      setError("Could not process and save the file.");
      throw e;
    } finally {
      setLoading(false);
    }
  };

  const updateJobStatus = (jobId: string, status: JobStatus) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;

    const updatedJobs = jobs.map(j => (j.id === jobId ? { ...j, status } : j));
    setJobs(updatedJobs);

    let action: ActivityAction;
    if (status === JobStatus.Approved) action = ActivityAction.APPROVED;
    else if (status === JobStatus.Printed) action = ActivityAction.PRINTED;
    else return;

    const updatedLog = addActivity(job, action, activityLog);
    updateLocalStorage(updatedJobs, updatedLog);
  };

  const deleteJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;

    const updatedJobs = jobs.filter(j => j.id !== jobId);
    setJobs(updatedJobs);
    
    const updatedLog = addActivity(job, ActivityAction.DELETED, activityLog);
    updateLocalStorage(updatedJobs, updatedLog);
  };

  // FIX: Replaced JSX with React.createElement to resolve parsing errors in a .ts file.
  return React.createElement(PrintJobsContext.Provider, { value: { jobs, activityLog, addJob, updateJobStatus, deleteJob, loading, error } }, children);
};

export const usePrintJobs = () => {
  const context = useContext(PrintJobsContext);
  if (context === undefined) {
    throw new Error('usePrintJobs must be used within a PrintJobsProvider');
  }
  return context;
};
