
import React from 'react';
import { HashRouter, Routes, Route, Link } from 'react-router-dom';
import StudentPortal from './components/StudentPortal';
import AdminPortal from './components/AdminPortal';
import { PrintJobsProvider } from './hooks/usePrintJobs';

function App() {
  return (
    <PrintJobsProvider>
      <div className="min-h-screen font-sans text-slate-800 dark:text-slate-200">
        <HashRouter>
          <Routes>
            <Route path="/" element={<StudentPortal />} />
            <Route path="/admin" element={<AdminPortal />} />
          </Routes>
        </HashRouter>
      </div>
    </PrintJobsProvider>
  );
}

export default App;
