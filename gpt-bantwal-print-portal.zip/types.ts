
export enum JobStatus {
  Uploaded = 'Uploaded',
  Approved = 'Approved',
  Printed = 'Printed',
}

export interface PrintJob {
  id: string;
  studentName: string;
  fileName: string;
  fileType: string;
  fileDataUrl: string; // File stored as a data URL
  fileSize: number; // in bytes
  copies: number;
  notes: string;
  status: JobStatus;
  timestamp: string; // ISO string
}

export enum ActivityAction {
    SUBMITTED = 'submitted a new job',
    APPROVED = 'approved job for printing',
    PRINTED = 'marked job as printed',
    DELETED = 'deleted job',
}

export interface ActivityLog {
  id: string;
  jobId: string;
  studentName: string;
  fileName: string;
  action: ActivityAction;
  timestamp: string; // ISO string
}
